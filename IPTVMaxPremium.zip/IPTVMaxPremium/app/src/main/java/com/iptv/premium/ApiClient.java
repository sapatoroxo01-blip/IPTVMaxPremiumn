package com.iptv.premium;

import android.content.Context;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.iptv.premium.model.Channel;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class ApiClient {
    private static final String BASE_URL = "http://ua40.org/";
    private static final String USERNAME = "jorgeebcastro";
    private static final String PASSWORD = "19583120034";

    public interface ApiCallback {
        void onSuccess(List<Channel> channels);
        void onError(String error);
    }

    public static void getLiveStreams(Context context, ApiCallback callback) {
        String url = BASE_URL + "player_api.php?username=" + USERNAME + "&password=" + PASSWORD + "&action=get_live_streams";
        
        RequestQueue queue = Volley.newRequestQueue(context);
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    List<Channel> channels = new ArrayList<>();
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject obj = response.getJSONObject(i);
                            channels.add(new Channel(
                                    obj.getString("name"),
                                    obj.getString("stream_id"),
                                    obj.getString("stream_icon"),
                                    obj.getString("category_id")
                            ));
                        }
                        callback.onSuccess(channels);
                    } catch (JSONException e) {
                        callback.onError(e.getMessage());
                    }
                },
                error -> callback.onError(error.getMessage()));
        
        queue.add(request);
    }

    public static String getStreamUrl(String streamId) {
        return BASE_URL + "live/" + USERNAME + "/" + PASSWORD + "/" + streamId + ".ts";
    }
}
