package com.iptv.premium.model;

public class Channel {
    private String name;
    private String streamId;
    private String streamIcon;
    private String categoryId;

    public Channel(String name, String streamId, String streamIcon, String categoryId) {
        this.name = name;
        this.streamId = streamId;
        this.streamIcon = streamIcon;
        this.categoryId = categoryId;
    }

    public String getName() { return name; }
    public String getStreamId() { return streamId; }
    public String getStreamIcon() { return streamIcon; }
    public String getCategoryId() { return categoryId; }
}
