package com.iptv.premium;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.iptv.premium.model.Channel;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ChannelAdapter.OnChannelClickListener {
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private ChannelAdapter adapter;
    private List<Channel> channelList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        progressBar = findViewById(R.id.progressBar);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        adapter = new ChannelAdapter(channelList, this);
        recyclerView.setAdapter(adapter);

        loadChannels();
    }

    private void loadChannels() {
        progressBar.setVisibility(View.VISIBLE);
        ApiClient.getLiveStreams(this, new ApiClient.ApiCallback() {
            @Override
            public void onSuccess(List<Channel> channels) {
                progressBar.setVisibility(View.GONE);
                channelList.clear();
                channelList.addAll(channels);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Erro: " + error, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onChannelClick(Channel channel) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("stream_id", channel.getStreamId());
        intent.putExtra("channel_name", channel.getName());
        startActivity(intent);
    }
}
