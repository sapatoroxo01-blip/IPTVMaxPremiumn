# IPTVMaxPremium - Player IPTV Completo

Este é um projeto Android Studio completo para um player IPTV integrado com a API Xtream Codes.

## Características
- **Linguagem:** Java
- **Player:** ExoPlayer (suporte a HLS, TS, etc.)
- **API:** Xtream Codes (Volley para requisições JSON)
- **UI:** RecyclerView com GridLayout, compatível com Mobile e Android TV (D-Pad focusable)
- **Orientação:** Landscape (Horizontal) por padrão para melhor experiência de TV.

## Configuração do Servidor
O app já vem pré-configurado com as seguintes credenciais:
- **URL:** http://ua40.org
- **User:** jorgeebcastro
- **Pass:** 19583120034

## Como Abrir no Android Studio
1. Extraia o arquivo ZIP.
2. Abra o Android Studio.
3. Vá em `File -> Open` e selecione a pasta `IPTVMaxPremium`.
4. Aguarde o Gradle sincronizar as dependências.
5. Clique em `Run` para instalar no seu dispositivo ou emulador.

## Requisitos
- Android 7.0 (API 24) ou superior.
- Conexão com a internet.
